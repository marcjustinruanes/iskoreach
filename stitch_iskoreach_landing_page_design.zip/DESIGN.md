---
name: Civic Horizon
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#43474d'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#001524'
  on-tertiary: '#ffffff'
  tertiary-container: '#002a44'
  on-tertiary-container: '#2e95da'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system positions itself at the intersection of institutional credibility and civic empowerment. Created for civic technology and educational mobility, it speaks to Filipino students, grassroots communities, and scholarship providers who demand both transparency and frictionless access. 

The emotional signature is dependable, optimistic, and clear. It balances the rigor of academic registries with the warm hospitality of community-driven support. Visually, the aesthetic follows a refined Modern Corporate and Humanist Civic standard: structured layouts, high typographic legibility, disciplined spacing, and purposeful color coding that eliminates bureaucratic anxiety.

## Colors
The palette balances institutional integrity with active opportunity. 

- **Primary (`#0F2942`)**: Deep Navy anchors top-level navigation, primary buttons, major headings, and trust-critical seals. It evokes academic governance, data security, and long-term institutional backing.
- **Secondary (`#0D9488`)**: Emerald Teal highlights action points, active applications, verified partner marks, and growth metrics. It represents progress, merit, and educational access.
- **Tertiary (`#0284C7`)**: Clear Civic Blue guides directional paths, links, and neutral informational callouts.
- **Surface Tints**: Soft Mint (`#F0FDF4`), Ice Blue (`#F0F7FF`), and Warm Slate (`#F8FAFC`) form subtle backgrounds for card decks, alert banners, and grouped filters without introducing visual weight.
- **Status Tokens**:
  - `Open / Active`: Emerald (`#059669`) with Light Mint base (`#ECFDF5`).
  - `Upcoming / Closing Soon`: Warm Amber (`#D97706`) with Ochre tint (`#FFFBEB`).
  - `Under Review / Processing`: Slate Blue (`#2563EB`) with Sky tint (`#EFF6FF`).
  - `Closed / Archived`: Slate (`#64748B`) with Neutral wash (`#F1F5F9`).

## Typography
Plus Jakarta Sans is selected across display, body, and UI labels. Its geometric foundations combined with open apertures deliver immediate warmth without compromising density in complex tabular data or scholarship criteria matrices.

- Numbers representing scholarship amounts, application deadlines, and quota counters must always be rendered with tabular figures (`font-variant-numeric: tabular-nums`).
- Headings maintain negative tracking (`-0.01em` to `-0.02em`) to eliminate visual slack in long program titles.
- Captions and tags use uppercase tracking (`0.02em` to `0.04em`) to safeguard legibility under constrained mobile viewports.

## Layout & Spacing
The layout follows a responsive 12-column grid system designed to scale gracefully from compact mobile screens (4 columns) to wide administrative monitors (12 columns).

- **Grid Strategy**:
  - Desktop (≥1280px): 12 columns, max-width of 1280px centered, 24px gutters, 32px canvas margins.
  - Tablet (768px - 1279px): 8 columns, fluid width, 20px gutters, 24px canvas margins.
  - Mobile (≤767px): 4 columns, fluid width, 16px gutters, 16px canvas margins.
- **Rhythm**: Spacing follows an 8pt base grid for macro structures and a 4pt sub-grid for badge padding, form fields, and meta lists. Vertical spacing between content blocks adheres strictly to `space-xl` on desktop and scales down to `space-lg` on mobile.

## Elevation & Depth
Depth is communicated through low-contrast outlines coupled with diffused, ambient lighting. This prevents visual clutter and ensures users on entry-level displays experience crisp visual hierarchy.

- **Level 0 (Flat)**: Backgrounds (`#FFFFFF` or `#F8FAFC`) with no shadow. Structural dividers rely on `border-slate-200` (`#E2E8F0`).
- **Level 1 (Card & Container)**: Base elevation for discovery cards and filter toolbars. Uses a subtle outline `border border-slate-200` paired with `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Hover / Floating Elements)**: Used for scholarship card hover states and elevated search modals. Transitions into `box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.06), 0 4px 6px -4px rgba(15, 23, 42, 0.03)` with a secondary border accent tint (`border-teal-500/30`).
- **Level 3 (Overlays & Drawers)**: Used for application detail drawers and contextual bottom sheets. `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`.

## Shapes
A roundedness level of 2 (`0.5rem` / 8px base) creates a balanced, approachable interface that retains structural discipline.

- **Base Components**: Text inputs, primary buttons, alert containers, and standard cards take an 8px radius (`rounded-lg` in standard utilities).
- **Composite Containers**: Modals, large scholarship showcase banners, and multi-step forms step up to 16px radius (`rounded-2xl`).
- **Interactive Tags & Badges**: Status indicators, filter pills, and meta tags employ fully rounded caps (`rounded-full`) to differentiate categorical labels from actionable cards and inputs.

## Components

### Buttons
- **Primary**: Solid Deep Navy (`#0F2942`) background, crisp white text, 8px radius, height 44px (touch target compliant). Hover shifts to `#1E3A5F` with subtle 2px transform lift.
- **Secondary / Action**: Solid Emerald Teal (`#0D9488`), white text, used strictly for conversion steps such as "Apply Now" or "Submit Requirements".
- **Outline / Filter**: Transparent background, `border border-slate-300`, Slate 700 text. Hover triggers `bg-slate-50` and `border-slate-400`.
- **Ghost**: Unbounded padding, Slate 600 text, hover reveals a gentle tint of `#F1F5F9`.

### Scholarship Cards
- Wrapped in a white background with a 1px border of `#E2E8F0` and an 8px radius.
- **Header**: Organization/donor avatar (40x40px, rounded), followed by scholarship title (Headline-sm, `#0F172A`) and provider verification checkmark.
- **Meta Row**: Deadline countdown tag (`#D97706` background tint if under 7 days), educational tier pill (e.g., "Undergraduate", "STEM"), and location scope.
- **Financial Metric**: Emphasized stipend or coverage amount rendered using bold tabular numbers in Secondary Emerald (`#0D9488`).
- **Footer**: Distinct split showing deadline progress bar and a compact secondary action button.

### Badges & Status Chips
- Height 24px, pill-shaped (`rounded-full`), horizontal padding `space-sm` (8px).
- Typography: `label-sm` font weight 700.
- State variants use paired border, text, and 10% opacity fills:
  - `Open`: Background `#ECFDF5`, text `#065F46`, border `#A7F3D0`.
  - `Closing Soon`: Background `#FFFBEB`, text `#92400E`, border `#FDE68A`.
  - `In Review`: Background `#EFF6FF`, text `#1E40AF`, border `#BFDBFE`.

### Pill Filters
- Scrollable horizontally on mobile with masked edge fades.
- Selected state: Deep Navy (`#0F2942`) fill with pure white label.
- Unselected state: Slate 100 (`#F1F5F9`) background, Slate 600 text, hover to `#E2E8F0`.

### Form Inputs & Search Fields
- 44px min-height, 8px radius, bordered in `#CBD5E1`.
- Focus state: Ring outline of 3px in teal tint (`rgba(13, 148, 136, 0.2)`) and border `#0D9488`.
- Search bars include an embedded leading search icon (`#94A3B8`) and an inline clear button.

### Checkboxes & Radio Controls
- Base dimension 18x18px.
- Checkboxes: 4px radius; Radios: circular.
- Selected state transitions to Teal (`#0D9488`) with crisp white check/dot indicators.

### Progress & Eligibility Indicators
- Progress bars: 6px height, rounded full, background `#E2E8F0` with Emerald Teal active fill.
- Eligibility checklist items utilize a split state: a muted bullet turns into a solid green verified circle when a student's profile matches the donor requirement.